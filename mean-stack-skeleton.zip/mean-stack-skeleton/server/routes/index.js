var express = require('express');
var router = express.Router();

var csrf = require('csurf');
var csrfProtection = csrf();
var LocalStrategy = require('passport-local').Strategy;
var User  = require('../models/userLogin');
var passport =require('passport');
// var passport = require('../config/passport')(passport);

router.use(csrfProtection);
var router = express.Router();


var user = require('../models/userLogin');




/* GET home page. */
router.get('/', function(req, res, next) {
	res.render('./client/index')
});
// router.get('/signup',function(req,res,next){
// 	var messages = req.flash('error');
//   res.render('./app/login/signup',{csrfToken: req.csrfToken(),messages:messages, hasError : messages.length>0});
// });

passport.serializeUser(function(user,done) {
	done(null,user.id);
});
passport.deserializeUser(function(id,done){
	User.findById(id,function(err,user){
		done(err,user);
	});
});

passport.use('local',new LocalStrategy(
  function(username, password, done) {
    User.findOne({ userName: userName }, function (err, user) {
    	console.log(err, user)
      if (err) { return done(err); }
      if (!user) {
        return done(null, false, { message: 'Incorrect username.' });
      }
      if (!user.validPassword(password)) {
        return done(null, false, { message: 'Incorrect password.' });
      }
      return done(null, user);
    });
  }
));
/*
passport.use('local', new LocalStrategy({
	usernameField: 'userName',
	passwordField: 'pwd',
	passReqToCallback : true
},function(req,userName,pwd,done){

	req.checkBody('userName','Invalid userName').notEmpty();
	req.checkBody('pwd','Invalid password').notEmpty().isLength({min:4});
	req.checkBody('role','Invalid role').notEmpty();
	console.log('check!!', userName)

	var errors = req.validationErrors();
	if(errors){
		var messages = [];
		errors.forEach(function(errors){
			messages.push(errors.msg);
		});
		console.log('xyz')
		return done(null,false,req.flash('error',messages));
	}

	//console.log()


	User.findOne({'userName':userName},function(err,user){

		console.log(err,user)
		if(err){
			console.log('err')
			return done(err);
		}
		if(	user) {
			console.log('user exist')
			return done (null,false,{message : 'userName is already in use'});
		}
		var newUser = new User();
		newUser.userName = userName;
		newUser.password = newUser.encryptPassword(pwd);
		newUser.role  = role;
		newUser.save(function(err,result){
			if(err){
				return done(err);
			}
			console.log('signup')
			return done(null, newUser);
		});
		console.log('hello world')

	});

}))*/

router.post('/signup', passport.authenticate('local',{
	successRedirect: '/',
	failureRedirect: '/client/app/login/signup',
	failureFlash: true
}));


module.exports = router;
