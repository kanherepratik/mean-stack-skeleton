var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var session = require('express-session');
var passport = require('passport');
var flash = require('connect-flash');
var validator = require('express-validator');
var mongoStore = require('connect-mongo')(session);

var routes = require('./routes/index');

var app = express();



// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(validator());
app.use(cookieParser());
app.use(session(
	{
	 secret: 'mysupersecret',
	 resave: false,
	 saveUninitialized:false ,
	 store : new mongoStore({mongooseConnection: mongoose.connection}),
	 cookie: {maxAge : 180 * 60 * 1000}
	}));
app.use(flash());
app.use(passport.initialize());
app.use(passport.session());
//app.use(cookieParser());
app.use(express.static(path.join(__dirname, '../client')));

app.use('/', routes);

module.exports = app;
