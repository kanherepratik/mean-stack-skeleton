var app = angular.module("JoinCI", ['ui.router','ui.bootstrap','ngStorage','ngMessages']);


app.config(function ($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.when("", "/login");

    $stateProvider
        .state("login", {
            url: "/login",
            views: {
            'main_section': { templateUrl: 'app/login/login.html', controller:"loginController" }  
         	}
        
        })
        .state("emp", {
            url: "/employee_list",
            views: {
            'main_section': { templateUrl: 'addEmp/employee_list.html', controller:"employeeController" },
            'header_section': { templateUrl: 'header/header_portion.html', controller:"headerController" }    
         	}
        
        })
        .state("resource", {
            url: "/resource_request",
            views: {
            'main_section': { templateUrl: 'addRes/resource.html', controller:"resourceAddController" },
            'header_section': { templateUrl: 'header/header_portion.html', controller:"headerController" }    
            }
        
        })
        .state("signup", {
            url: "/signup",
            views: {
            'main_section': { templateUrl: 'app/login/signup.html', controller:"loginController" }
            }
        
        })
        .state("FAQ", {
            url: "/faq",
            views: {
            'main_section': { templateUrl: 'addRes/faq.html', controller:"resourceAddController" },
            'header_section': { templateUrl: 'header/header_portion.html', controller:"headerController" }    
            }
        
        });
        
        
});